# Obsah mapy

## Vyskopis + polohopis + popis



### Vyskopis

- **Historicke metody**
  - Stromeckova - kde jsou vysiny jsou tam namalovany stromecky
  - Kopeckova - stejny jak to druhy, ale jsou tam namalovany kopecky
  - Srafovani/stinovani - vysiny atd jsou srafovany/malovany jinym odstinem nez zbytek mapy
- **Soucasne metody**
  - V prehlednych mapach je barevna skala topogafickeho zobrazeni
  - Topograficke mapy maji vrstevnice

### Popis

- Ruzne normy pro zapis nazvu statu/osrtovu jezer mori atd

### Polohopis

- Znackovy klic - popis symbolu a barev na mape - bodove znacky
  - Bodove znacky nejsou v realnem meritku vuci objektum, ktere reprezentuji 
- Vyznam silnic, zeleznic, cest je urcen silou cary a typy se rozlisuji typem cary