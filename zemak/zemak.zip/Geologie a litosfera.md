# Geologie a litosfera

## Bullenovy zony - cleneni zemskeho telesa

- plochy nespojitosti / diskontinuity -> plochy od kterych se meni smer odrazu vln (zmena prostredi)

- Kura
  - Mezi kurou a plastem plocha Mohorovicicova
- Plast
  - Mezi plastem a jadrem je Wiechert-Gutenbergova plocha
- Jadro

## Litosfera - atmosfera + zemska kura

- pevninska zk - zula (**granit**), cedic
  - zula obsahuje nerostne bohatsvi 
- oceanska zk - jen cedic (**bazalt**)