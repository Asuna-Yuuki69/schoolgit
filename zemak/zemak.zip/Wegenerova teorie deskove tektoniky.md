# Wegenerova teorie deskove tektoniky

- je potvrzena
- pracoval bez znalosti oceanskeho dna 
- pohyb litosferickych desek
- lit.deskz s pohybuji protoze jsou nadnaseny 
- vysvetlenim je astenosfera
- je nestejnomerne zahrivana
- pod mistem kde se rozestupuji desky je misto zvane hotspot